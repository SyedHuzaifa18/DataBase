import tkinter as tk
from tkinter import ttk, messagebox
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime
from PIL import Image, ImageTk

class LibraryManager:
    def __init__(self, master):
        self.master = master
        self.master.title("Huzaifa Kamal Library Portal")
        self.master.geometry("1100x650")
        self.master.configure(bg="#F5DEB3")
        
        # Initialize database connection
        self.db_client = MongoClient("mongodb://localhost:27017/")
        self.library_db = self.db_client["library_management"]
        self.books = self.library_db["book_collection"]
        self.transactions = self.library_db["book_transactions"]
        
        # Setup UI
        self.setup_ui()
        self.load_initial_data()
        
    def setup_ui(self):
        """Initialize all UI components"""
        self.create_header()
        self.create_book_management_section()
        self.create_lending_section()
        self.create_footer_controls()
        
    def create_header(self):
        """Create application header with title and logo"""
        header_frame = tk.Frame(self.master, bg="#8B4513")
        header_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Application title
        title = tk.Label(
            header_frame, 
            text="Huzaifa Kamal Digital Library", 
            font=("Georgia", 22, "bold"), 
            bg="#8B4513", 
            fg="white"
        )
        title.pack(side=tk.LEFT, padx=10, pady=10)
        
        # Logo placeholder
        try:
            logo_img = Image.open("huzaifa_logo.png")
            logo_img = logo_img.resize((500, 150))
            self.logo = ImageTk.PhotoImage(logo_img)
            logo_label = tk.Label(header_frame, image=self.logo, bg="#8B4513")
            logo_label.pack(side=tk.RIGHT, padx=10)
        except:
            pass
        
    def create_book_management_section(self):
        """Create book inventory management interface"""
        book_frame = tk.LabelFrame(
            self.master, 
            text="Book Inventory Management", 
            font=("Arial", 12, "bold"),
            bg="#F5DEB3",
            padx=10,
            pady=10
        )
        book_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Book entry form
        entry_frame = tk.Frame(book_frame, bg="#F5DEB3")
        entry_frame.pack(fill=tk.X, pady=5)
        
        fields = ["Title", "Author", "Genre", "Quantity"]
        self.book_entries = {}
        
        for i, field in enumerate(fields):
            tk.Label(entry_frame, text=field, bg="#F5DEB3").grid(row=0, column=i*2, padx=5)
            entry = tk.Entry(entry_frame, width=20)
            entry.grid(row=0, column=i*2+1, padx=5)
            self.book_entries[field.lower()] = entry
            
        # Action buttons
        btn_frame = tk.Frame(book_frame, bg="#F5DEB3")
        btn_frame.pack(fill=tk.X, pady=5)
        
        actions = [
            ("Add Book", self.add_new_book),
            ("Remove Book", self.remove_book),
            ("Refresh List", self.display_books)
        ]
        
        for i, (text, cmd) in enumerate(actions):
            btn = tk.Button(
                btn_frame, 
                text=text, 
                command=cmd,
                bg="#CD853F",
                fg="white",
                width=15
            )
            btn.grid(row=0, column=i, padx=5)
        
        # Book list display
        columns = ("ID", "Title", "Author", "Category", "Available")
        self.book_list = ttk.Treeview(
            book_frame, 
            columns=columns, 
            show='headings',
            height=8
        )
        
        for col in columns:
            self.book_list.heading(col, text=col)
            self.book_list.column(col, width=150, anchor=tk.CENTER)
            
        scrollbar = ttk.Scrollbar(book_frame, orient=tk.VERTICAL, command=self.book_list.yview)
        self.book_list.configure(yscrollcommand=scrollbar.set)
        
        self.book_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
    def create_lending_section(self):
        """Create book lending/returning interface"""
        lend_frame = tk.LabelFrame(
            self.master, 
            text="Book Circulation System", 
            font=("Arial", 12, "bold"),
            bg="#F5DEB3",
            padx=10,
            pady=10
        )
        lend_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Lending form
        form_frame = tk.Frame(lend_frame, bg="#F5DEB3")
        form_frame.pack(fill=tk.X, pady=5)
        
        # Book selection
        tk.Label(form_frame, text="Select Book:", bg="#F5DEB3").grid(row=0, column=0, padx=5)
        self.selected_book = tk.StringVar()
        self.book_menu = ttk.Combobox(
            form_frame, 
            textvariable=self.selected_book,
            state="readonly",
            width=30
        )
        self.book_menu.grid(row=0, column=1, padx=5)
        self.book_menu.set("-- Select Book --")
        
        # Borrower info
        tk.Label(form_frame, text="Borrower Name:", bg="#F5DEB3").grid(row=0, column=2, padx=5)
        self.borrower_entry = tk.Entry(form_frame, width=25)
        self.borrower_entry.grid(row=0, column=3, padx=5)
        
        # Dates
        tk.Label(form_frame, text="Borrow Date:", bg="#F5DEB3").grid(row=1, column=0, padx=5)
        self.borrow_date = tk.Entry(form_frame, width=15)
        self.borrow_date.insert(0, datetime.now().strftime('%Y-%m-%d'))
        self.borrow_date.grid(row=1, column=1, padx=5)
        
        tk.Label(form_frame, text="Return Date:", bg="#F5DEB3").grid(row=1, column=2, padx=5)
        self.return_date = tk.Entry(form_frame, width=15)
        self.return_date.grid(row=1, column=3, padx=5)
        
        # Action buttons
        btn_frame = tk.Frame(lend_frame, bg="#F5DEB3")
        btn_frame.pack(fill=tk.X, pady=5)
        
        actions = [
            ("Lend Book", self.process_lending),
            ("Return Book", self.process_return),
            ("Refresh Records", self.display_transactions)
        ]
        
        for i, (text, cmd) in enumerate(actions):
            btn = tk.Button(
                btn_frame, 
                text=text, 
                command=cmd,
                bg="#CD853F",
                fg="white",
                width=15
            )
            btn.grid(row=0, column=i, padx=5)
        
        # Transaction records
        columns = ("ID", "Book Title", "Borrower", "Checkout Date", "Due Date")
        self.transaction_list = ttk.Treeview(
            lend_frame, 
            columns=columns, 
            show='headings',
            height=8
        )
        
        for col in columns:
            self.transaction_list.heading(col, text=col)
            self.transaction_list.column(col, width=150, anchor=tk.CENTER)
            
        scrollbar = ttk.Scrollbar(lend_frame, orient=tk.VERTICAL, command=self.transaction_list.yview)
        self.transaction_list.configure(yscrollcommand=scrollbar.set)
        
        self.transaction_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
    def create_footer_controls(self):
        """Create footer with additional controls"""
        footer = tk.Frame(self.master, bg="#8B4513")
        footer.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Button(
            footer, 
            text="Export Data", 
            command=self.export_data,
            bg="#A0522D",
            fg="white"
        ).pack(side=tk.LEFT, padx=10, pady=5)
        
        tk.Button(
            footer, 
            text="Exit System", 
            command=self.master.quit,
            bg="#A0522D",
            fg="white"
        ).pack(side=tk.RIGHT, padx=10, pady=5)
        
    def load_initial_data(self):
        """Load initial data into the interface"""
        self.update_book_selection()
        self.display_books()
        self.display_transactions()
        
    def add_new_book(self):
        """Add a new book to the inventory"""
        try:
            book_data = {
                "title": self.book_entries["title"].get().strip(),
                "author": self.book_entries["author"].get().strip(),
                "genre": self.book_entries["genre"].get().strip(),
                "quantity": int(self.book_entries["quantity"].get())
            }
            
            if not all(book_data.values()):
                messagebox.showwarning("Incomplete Data", "Please fill all book details")
                return
                
            self.books.insert_one(book_data)
            messagebox.showinfo("Success", "Book added to inventory successfully!")
            
            # Clear form and refresh displays
            for entry in self.book_entries.values():
                entry.delete(0, tk.END)
                
            self.update_book_selection()
            self.display_books()
            
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid quantity")
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to add book: {str(e)}")
            
    def remove_book(self):
        """Remove selected book from inventory"""
        selected = self.book_list.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Please select a book to remove")
            return
            
        try:
            item = self.book_list.item(selected[0])
            book_id = item["values"][0]
            
            # Get actual MongoDB ID from the displayed serial number
            all_books = list(self.books.find())
            if 0 < book_id <= len(all_books):
                book_to_remove = all_books[book_id-1]
                self.books.delete_one({"_id": book_to_remove["_id"]})
                messagebox.showinfo("Success", "Book removed from inventory")
                self.update_book_selection()
                self.display_books()
            else:
                messagebox.showerror("Error", "Invalid book selection")
                
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to remove book: {str(e)}")

    def process_lending(self):
        """Process book lending transaction"""
        book_title = self.selected_book.get()
        borrower = self.borrower_entry.get().strip()
        borrow_date = self.borrow_date.get().strip()
        return_date = self.return_date.get().strip()
        
        if not all([book_title, borrower, borrow_date, return_date]):
            messagebox.showwarning("Incomplete Data", "Please fill all lending details")
            return
            
        if book_title == "-- Select Book --":
            messagebox.showwarning("Invalid Selection", "Please select a valid book")
            return
            
        try:
            # Check book availability
            book = self.books.find_one({"title": book_title})
            if not book or book["quantity"] <= 0:
                messagebox.showwarning("Unavailable", "Selected book is not available")
                return
                
            # Record transaction
            transaction_data = {
                "book_title": book_title,
                "borrower_name": borrower,
                "borrow_date": borrow_date,
                "return_date": return_date,
                "book_id": book["_id"]  # Store the book ID for reference
            }
            result = self.transactions.insert_one(transaction_data)
            
            # Update inventory
            self.books.update_one(
                {"_id": book["_id"]},
                {"$inc": {"quantity": -1}}
            )
            
            messagebox.showinfo("Success", f"Book '{book_title}' lent to {borrower}")
            
            # Clear form and refresh
            self.borrower_entry.delete(0, tk.END)
            self.return_date.delete(0, tk.END)
            self.update_book_selection()
            self.display_books()
            self.display_transactions()
            
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to process lending: {str(e)}")

    def process_return(self):
        """Process book return transaction"""
        selected = self.transaction_list.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Please select a transaction")
            return
        
        try:
            item = self.transaction_list.item(selected[0])
            values = item['values']
            transaction_id = values[0]  # This is the displayed short ID

            book_title = values[1]
            borrower = values[2]

        # Find the full transaction record with all fields
            transaction = self.transactions.find_one({
                "book_title": book_title,
                "borrower_name": borrower
            })

            if not transaction:
                messagebox.showerror("Error", "Transaction record not found")
                return

        # Ensure 'book_id' is present in the transaction
            book_id = transaction.get("book_id")
            if not book_id:
                messagebox.showerror("Error", "book_id missing in transaction record")
                return

        # Update book quantity
            self.books.update_one(
                {"_id": book_id},
                {"$inc": {"quantity": 1}}
            )

        # Delete the transaction
            self.transactions.delete_one({"_id": transaction["_id"]})

            messagebox.showinfo("Success", f"Book '{book_title}' returned successfully")
            self.update_book_selection()
            self.display_books()
            self.display_transactions()

        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to process return: {str(e)}")


    def display_books(self):
        """Display all books in inventory"""
        for item in self.book_list.get_children():
            self.book_list.delete(item)
            
        for i, book in enumerate(self.books.find(), 1):
            self.book_list.insert("", tk.END, values=(
                i,
                book["title"],
                book["author"],
                book["genre"],
                book["quantity"]
            ))
            
    def display_transactions(self):
        """Display all lending transactions"""
        for item in self.transaction_list.get_children():
            self.transaction_list.delete(item)
            
        for record in self.transactions.find():
            self.transaction_list.insert("", tk.END, 
                values=(
                    str(record["_id"])[:6],  # Display first 6 chars of ID
                    record["book_title"],
                    record["borrower_name"],
                    record["borrow_date"],
                    record["return_date"]
                ))
                
    def update_book_selection(self):
        """Update dropdown with available books"""
        available_books = ["-- Select Book --"] + [
            book["title"] for book in self.books.find({"quantity": {"$gt": 0}})
        ]
        self.book_menu["values"] = available_books
        self.book_menu.set("-- Select Book --")
        
    def export_data(self):
        """Placeholder for data export functionality"""
        messagebox.showinfo("Info", "Data export functionality will be implemented here")
        
    def run(self):
        """Run the application"""
        self.master.mainloop()

if __name__ == "__main__":
    root = tk.Tk()
    app = LibraryManager(root)
    app.run()